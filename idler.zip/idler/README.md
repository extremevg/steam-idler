# Steam Idler Panel

Painel simples em Node.js para "farmar" horas em jogos da Steam, mantendo as sessões ativas de forma organizada.

> ⚠️ **Aviso:** use por sua conta e risco. Respeite sempre os Termos de Uso da Steam e da plataforma onde o idler é utilizado.

---

## ✨ Funcionalidades

- Interface em painel (HTML) para controlar o idler.
- Scripts em lote (`.bat`) para iniciar o servidor rapidamente.
- Logs de execução para acompanhar o funcionamento.
- Arquitetura baseada em Node.js.

---

## 📂 Estrutura do projeto

```text
meu-idler/
  logs/                # Logs de execução
  node_modules/        # Dependências Node (geradas pelo npm)
  .env                 # Variáveis de ambiente (NÃO subir no GitHub)
  billing.json         # Configurações de billing/licença (se usado)
  generate-keys.js     # Script para gerar keys
  idler.log            # Log do idler
  iniciar-idler.bat    # Atalho para iniciar o idler
  loader.bat           # Script auxiliar/loader
  package.json         # Metadados do projeto e dependências
  package-lock.json    # Versões travadas das dependências
  panel.html           # Painel web do idler
  server.js            # Servidor principal em Node.js
  README.md            # Documentação do projeto
