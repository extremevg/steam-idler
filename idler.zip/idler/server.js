// server.js
const express = require('express');
const SteamUser = require('steam-user');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.use(express.json());
app.use(cors());

// === Servir o painel e arquivos estáticos ===
app.use(express.static(path.join(__dirname)));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'panel.html'));
});

// ====== Steam client (uma conta por vez) ======
const client = new SteamUser();

let isLogged = false;
let isIdling = false;
let currentApps = [];
let currentAccount = null;
let currentSteamId = null;
let activeToken = null; // token da conta atualmente logada

// sessions[token] = { account, username, favorites, credentials, lastIdleApps, autoIdle }
const sessions = {};

const LOG_FILE = path.join(__dirname, 'idler.log');

// Reconnect
let reconnectAttempts = 0;
const MAX_RECONNECT = 5;
let reconnectTimeout = null;

// ====== BILLING (keys + horas) ======
const BILLING_FILE = path.join(__dirname, 'billing.json');

function loadBilling() {
  try {
    const raw = fs.readFileSync(BILLING_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    return { users: {}, keys: {} };
  }
}

function saveBilling(data) {
  fs.writeFileSync(BILLING_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// garante que o usuário existe na estrutura de billing
function getBillingUser(billing, username) {
  if (!billing.users[username]) {
    billing.users[username] = {
      hoursRemaining: 0,
      totalUsedMs: 0,
      currentSessionStart: null
    };
  }
  return billing.users[username];
}

// desconta tempo de sessão do saldo
function consumeTimeFromUser(username, endTimeMs) {
  const billing = loadBilling();
  const user = getBillingUser(billing, username);

  if (!user.currentSessionStart) {
    saveBilling(billing);
    return;
  }

  const start = user.currentSessionStart;
  const elapsedMs = Math.max(0, endTimeMs - start);
  if (elapsedMs <= 0) {
    user.currentSessionStart = null;
    saveBilling(billing);
    return;
  }

  user.totalUsedMs += elapsedMs;

  const elapsedHours = elapsedMs / (1000 * 60 * 60);
  user.hoursRemaining = Math.max(0, user.hoursRemaining - elapsedHours);

  user.currentSessionStart = null;
  saveBilling(billing);

  logLine(
    `Cobrança: ${username} usou ~${elapsedHours.toFixed(
      3
    )}h nesta sessão. Saldo agora: ${user.hoursRemaining.toFixed(3)}h.`
  );
}

// ====== helpers gerais ======

function logLine(msg) {
  const now = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const line = `[${now}] ${msg}`;
  console.log(line);
  fs.appendFile(LOG_FILE, line + '\n', () => {});
}

function createToken() {
  return crypto.randomBytes(24).toString('hex');
}

function getTokenFromReq(req) {
  const auth = req.headers.authorization || '';
  if (!auth.startsWith('Bearer ')) return null;
  return auth.slice(7);
}

function authMiddleware(req, res, next) {
  const token = getTokenFromReq(req);
  if (!token || !sessions[token]) {
    return res.status(401).json({
      ok: false,
      error: 'Sessão inválida ou expirada. Faça login novamente.'
    });
  }

  // Só permitimos 1 conta ativa na Steam por vez
  if (activeToken && token !== activeToken) {
    return res.status(403).json({
      ok: false,
      error: 'Outra conta está ativa no momento neste servidor.'
    });
  }

  req.token = token;
  req.session = sessions[token];
  next();
}

function resetSteamState() {
  isLogged = false;
  isIdling = false;
  currentApps = [];
  currentAccount = null;
  currentSteamId = null;
}

// ====== RECONNECT / AUTO IDLE ======

function clearReconnectState() {
  reconnectAttempts = 0;
  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }
}

function doReconnect(sess) {
  if (!sess || !sess.credentials) {
    logLine('Sem credenciais salvas para reconectar.');
    return;
  }

  function cleanup() {
    client.removeListener('loggedOn', onReLoggedOn);
    client.removeListener('error', onReError);
  }

  const onReLoggedOn = () => {
    cleanup();
    resetSteamState();
    isLogged = true;
    currentAccount = sess.username;
    currentSteamId = client.steamID ? String(client.steamID) : null;
    client.setPersona(SteamUser.EPersonaState.Online);

    logLine(`Reconectado na Steam como ${currentAccount}.`);
    clearReconnectState();
    activeToken = sess.token;

    // Auto Idle: retoma jogos da última sessão
    if (sess.autoIdle && Array.isArray(sess.lastIdleApps) && sess.lastIdleApps.length > 0) {
      const numericIds = sess.lastIdleApps
        .map(id => parseInt(id, 10))
        .filter(n => !isNaN(n));

      if (numericIds.length > 0) {
        const billing = loadBilling();
        const billUser = getBillingUser(billing, currentAccount);

        client.gamesPlayed(numericIds);
        isIdling = true;
        currentApps = numericIds.map(String);

        billUser.currentSessionStart = Date.now();
        saveBilling(billing);

        logLine(
          `Auto-Idle: retomado idling dos apps ${currentApps.join(
            ', '
          )}. Cobrança retomada a partir de agora.`
        );
      }
    }
  };

  const onReError = (err) => {
    cleanup();
    const msg = err && err.message ? err.message : String(err || '');
    logLine(`Erro ao tentar reconectar: ${msg}`);
    scheduleReconnect('erro ao reconectar');
  };

  client.once('loggedOn', onReLoggedOn);
  client.once('error', onReError);

  logLine(`Tentando reconectar na Steam para ${sess.username}...`);
  client.logOn({
    accountName: sess.credentials.username,
    password: sess.credentials.password
  });
}

function scheduleReconnect(reason) {
  if (!activeToken) {
    logLine(`Conexão perdida (${reason}), mas não há token ativo. Não será feito reconnect automático.`);
    return;
  }

  const sess = sessions[activeToken];
  if (!sess || !sess.credentials) {
    logLine(`Conexão perdida (${reason}), mas não há credenciais salvas para o token ativo.`);
    return;
  }

  if (reconnectAttempts >= MAX_RECONNECT) {
    logLine(`Conexão perdida (${reason}). Limite de tentativas (${MAX_RECONNECT}) atingido. Parando auto-reconnect.`);
    return;
  }

  reconnectAttempts += 1;
  const delay = 5000 * reconnectAttempts; // 5s, 10s, 15s...

  logLine(`Conexão perdida (${reason}). Tentativa de reconectar #${reconnectAttempts} em ${delay / 1000}s...`);

  if (reconnectTimeout) clearTimeout(reconnectTimeout);

  reconnectTimeout = setTimeout(() => {
    doReconnect({ ...sess, token: activeToken });
  }, delay);
}

// Evento global de desconexão (quedas, timeouts, etc.)
client.on('disconnected', (eresult, msg) => {
  const reason = `${eresult || ''} ${msg || ''}`.trim();
  logLine(`Desconectado da Steam: ${reason || 'sem motivo informado'}`);

  // se estava idlando, cobra até o momento da queda
  if (isIdling && currentAccount) {
    consumeTimeFromUser(currentAccount, Date.now());
  }

  resetSteamState();
  scheduleReconnect('desconectado');
});

// ====== LOGIN STEAM (gera token) ======

app.post('/api/loginSteam', (req, res) => {
  const { username, password, autoIdle } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({
      ok: false,
      error: 'Informe usuário e senha da Steam.'
    });
  }

  logLine(`Requisição de login para usuário: ${username}`);

  // Se já está logado em outra conta, desloga antes
  if (isLogged) {
    try {
      client.gamesPlayed([]);
      client.logOff();
      logLine(`Deslogando conta anterior (${currentAccount}) para novo login.`);
    } catch (_) {}
    resetSteamState();
    activeToken = null;
  }

  function cleanup() {
    client.removeListener('loggedOn', onLoggedOn);
    client.removeListener('error', onError);
  }

  const onLoggedOn = () => {
    cleanup();
    resetSteamState();
    isLogged = true;
    isIdling = false;
    currentApps = [];
    currentAccount = username;
    currentSteamId = client.steamID ? String(client.steamID) : null;

    client.setPersona(SteamUser.EPersonaState.Online);

    const token = createToken();
    activeToken = token;

    const autoIdleFlag = typeof autoIdle === 'boolean' ? autoIdle : true;

    sessions[token] = sessions[token] || {
      favorites: [],
      lastIdleApps: [],
    };
    sessions[token].account = username;
    sessions[token].username = username;
    sessions[token].credentials = { username, password };
    sessions[token].autoIdle = autoIdleFlag;

    clearReconnectState();

    const billing = loadBilling();
    const billUser = getBillingUser(billing, username);
    saveBilling(billing);

    logLine(
      `Login bem-sucedido para ${username} (token gerado). AutoIdle=${autoIdleFlag}. Saldo: ${billUser.hoursRemaining.toFixed(
        3
      )}h`
    );

    return res.json({
      ok: true,
      account: username,
      token,
      steamId: currentSteamId
    });
  };

  const onError = (err) => {
    cleanup();
    resetSteamState();
    activeToken = null;

    let message = 'Erro ao logar na Steam.';
    if (err && err.message) message = err.message;

    logLine(`Erro Steam ao logar (${username}): ${message}`);

    return res.status(400).json({
      ok: false,
      error: message,
      code: err && err.eresult
    });
  };

  client.once('loggedOn', onLoggedOn);
  client.once('error', onError);

  client.logOn({
    accountName: username,
    password: password
  });
});

// ====== START IDLING (com cobrança de horas) ======

app.post('/api/start', authMiddleware, (req, res) => {
  const { appIds } = req.body || {};

  if (!isLogged) {
    return res.status(400).json({
      ok: false,
      error: 'Não está logado na Steam.'
    });
  }

  if (!Array.isArray(appIds) || appIds.length === 0) {
    return res.status(400).json({
      ok: false,
      error: 'Envie uma lista de AppIDs.'
    });
  }

  const numericIds = appIds.map(id => parseInt(id, 10)).filter(n => !isNaN(n));

  if (numericIds.length === 0) {
    return res.status(400).json({
      ok: false,
      error: 'Nenhum AppID válido foi enviado.'
    });
  }

  const username = currentAccount;
  if (!username) {
    return res.status(400).json({
      ok: false,
      error: 'Não foi possível identificar a conta. Faça login novamente.'
    });
  }

  const billing = loadBilling();
  const billUser = getBillingUser(billing, username);

  if (billUser.hoursRemaining <= 0) {
    saveBilling(billing);
    return res.status(403).json({
      ok: false,
      error: 'Sem horas disponíveis. Ative uma key para continuar usando o idler.'
    });
  }

  // se já tinha sessão aberta, cobra antes de começar outra
  if (billUser.currentSessionStart) {
    consumeTimeFromUser(username, Date.now());
  }

  client.gamesPlayed(numericIds);
  isIdling = true;
  currentApps = numericIds.map(String);

  billUser.currentSessionStart = Date.now();
  saveBilling(billing);

  // Salva para Auto Idle dessa conta
  const sess = sessions[req.token];
  if (sess) {
    sess.lastIdleApps = currentApps.slice();
    if (typeof sess.autoIdle !== 'boolean') sess.autoIdle = true;
  }

  logLine(
    `Idling iniciado para conta ${currentAccount} (token: ${req.token}) apps: ${currentApps.join(
      ', '
    )}. Saldo: ${billUser.hoursRemaining.toFixed(3)}h`
  );

  res.json({
    ok: true,
    hoursRemaining: billUser.hoursRemaining
  });
});

// ====== STOP IDLING (cobra horas usadas) ======

app.post('/api/stop', authMiddleware, (req, res) => {
  if (!isLogged) {
    return res.status(400).json({
      ok: false,
      error: 'Não está logado.'
    });
  }

  client.gamesPlayed([]);
  isIdling = false;
  currentApps = [];

  const username = currentAccount;
  if (username) {
    consumeTimeFromUser(username, Date.now());
  }

  logLine(`Idling parado para conta ${currentAccount} (token: ${req.token}).`);

  res.json({ ok: true });
});

// ====== STATUS ======

app.get('/api/status', authMiddleware, (req, res) => {
  const username = currentAccount;
  const billing = loadBilling();
  const userBilling = username ? getBillingUser(billing, username) : null;

  return res.json({
    ok: true,
    logged: isLogged,
    idling: isIdling,
    apps: currentApps,
    account: currentAccount,
    steamId: currentSteamId,
    hoursRemaining: userBilling ? userBilling.hoursRemaining : 0
  });
});

// ====== FAVORITOS (jogos custom por conta) ======

app.get('/api/favorites', authMiddleware, (req, res) => {
  const sess = req.session;
  return res.json({
    ok: true,
    games: Array.isArray(sess.favorites) ? sess.favorites : []
  });
});

app.post('/api/favorites', authMiddleware, (req, res) => {
  const { games } = req.body || {};
  if (!Array.isArray(games)) {
    return res.status(400).json({
      ok: false,
      error: 'Envie um array "games".'
    });
  }

  sessions[req.token].favorites = games;
  logLine(
    `Favoritos atualizados para conta ${sessions[req.token].account} (qtd: ${games.length}).`
  );

  return res.json({ ok: true });
});

// ====== LICENÇAS: ATIVAR KEY ======

app.post('/api/redeemKey', authMiddleware, (req, res) => {
  const { key } = req.body || {};
  const username = currentAccount;

  if (!key || typeof key !== 'string') {
    return res.status(400).json({
      ok: false,
      error: 'Informe uma key válida.'
    });
  }

  if (!username) {
    return res.status(400).json({
      ok: false,
      error: 'Nenhuma conta Steam está ligada a esta sessão.'
    });
  }

  const normalized = key.trim().toUpperCase();
  const billing = loadBilling();
  const entry = billing.keys[normalized];

  if (!entry) {
    return res.status(404).json({
      ok: false,
      error: 'Key não encontrada. Confira se digitou certinho.'
    });
  }

  if (entry.used) {
    return res.status(400).json({
      ok: false,
      error: `Esta key já foi usada por ${entry.usedBy}.`
    });
  }

  const hoursToAdd = Number(entry.hours || 0);
  if (!hoursToAdd || hoursToAdd <= 0) {
    return res.status(400).json({
      ok: false,
      error: 'Esta key não possui horas configuradas.'
    });
  }

  const user = getBillingUser(billing, username);
  user.hoursRemaining += hoursToAdd;

  entry.used = true;
  entry.usedBy = username;
  entry.usedAt = new Date().toISOString();

  saveBilling(billing);

  logLine(
    `Key ${normalized} ativada por ${username}. +${hoursToAdd}h. Saldo agora: ${user.hoursRemaining.toFixed(
      3
    )}h`
  );

  return res.json({
    ok: true,
    addedHours: hoursToAdd,
    hoursRemaining: user.hoursRemaining
  });
});

// ====== LICENÇAS: CONSULTAR SALDO ======

app.get('/api/balance', authMiddleware, (req, res) => {
  const username = currentAccount;
  if (!username) {
    return res.status(400).json({
      ok: false,
      error: 'Nenhuma conta Steam ativa.'
    });
  }
  const billing = loadBilling();
  const user = getBillingUser(billing, username);
  return res.json({
    ok: true,
    hoursRemaining: user.hoursRemaining,
    totalUsedHours: user.totalUsedMs / (1000 * 60 * 60)
  });
});

// ====== LOGOUT ======

app.post('/api/logout', authMiddleware, (req, res) => {
  const token = req.token;
  const sess = sessions[token];
  const name = sess ? sess.account : 'desconhecida';

  // se estava idlando, cobra até agora
  if (isLogged && currentAccount) {
    consumeTimeFromUser(currentAccount, Date.now());
  }

  // só desloga de fato se essa for a conta ativa
  if (activeToken === token && isLogged) {
    try {
      client.gamesPlayed([]);
      client.logOff();
    } catch (_) {}

    resetSteamState();
    activeToken = null;
    clearReconnectState();

    logLine(`Logout solicitado pela conta ativa: ${name}.`);
  } else {
    logLine(`Logout de token não ativo: ${name}. (só remove token local)`);
  }

  return res.json({ ok: true });
});

// ====== HEALTH (sem auth, só pra painel ver se o servidor responde) ======

app.get('/api/health', (req, res) => {
  const countSessions = Object.keys(sessions).length;
  return res.json({
    ok: true,
    sessions: countSessions,
    activeAccount: currentAccount,
    tokenTtlMinutes: 0 // sem TTL real, tudo em memória
  });
});

// ====== LOGS (precisa estar autenticado) ======

app.get('/api/logs', authMiddleware, (req, res) => {
  const limit = parseInt(req.query.limit, 10) || 200;

  fs.readFile(LOG_FILE, 'utf8', (err, data) => {
    if (err) {
      if (err.code === 'ENOENT') {
        return res.json({ ok: true, lines: [] });
      }
      return res.status(500).json({
        ok: false,
        error: 'Não foi possível ler o arquivo de log.'
      });
    }

    const allLines = data.split('\n').filter(Boolean);
    const lastLines = allLines.slice(-limit);

    return res.json({
      ok: true,
      lines: lastLines
    });
  });
});

// ====== START SERVER ======

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor IdleManager ouvindo em http://localhost:${PORT}`);
  logLine('Servidor iniciado.');
});
