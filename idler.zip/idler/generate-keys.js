const fs = require('fs');
const crypto = require('crypto');

const BILLING_FILE = './billing.json';

// Carrega o arquivo billing.json
function loadBilling() {
  if (!fs.existsSync(BILLING_FILE)) {
    return { users: {}, keys: {} };
  }
  return JSON.parse(fs.readFileSync(BILLING_FILE, 'utf8'));
}

// Salva no billing.json
function saveBilling(data) {
  fs.writeFileSync(BILLING_FILE, JSON.stringify(data, null, 2));
}

// Gera a key e grava no billing.json
function generateKey(hours) {
  // gera uma string aleatória tipo “A4F9...”
  const key = crypto.randomBytes(12).toString('hex').toUpperCase();

  const billing = loadBilling();

  // salva a key dentro de billing.keys
  billing.keys[key] = {
    hours,          // quantas horas essa key vale
    used: false,    // ainda não usada
    usedBy: null,   // quem usou
    usedAt: null    // quando foi usada
  };

  saveBilling(billing);

  console.log("\n==============================");
  console.log(" 🔑 KEY GERADA COM SUCESSO!");
  console.log("==============================");
  console.log(`Key: ${key}`);
  console.log(`Horas: ${hours}`);
  console.log("==============================\n");

  return key;
}

// Pega o valor das horas pelo argumento do comando
// Exemplo: node generateKey.js 1000
const hours = parseInt(process.argv[2], 10);

if (!hours) {
  console.log("❌ Use assim:  node generateKey.js 1000");
  process.exit(0);
}

// chama a função pra gerar
generateKey(hours);
